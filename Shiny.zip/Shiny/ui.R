# Load data.table package
require(data.table)

# reading "new_variables file"
cap_data <- as.data.table(read.csv("Data/new_variables.csv",header = TRUE))

# Define User Interface function
shinyUI(fluidPage(
  titlePanel('Machine Learning to Identify "Sister Cities" in US', windowTitle = 'Capstone Project: Krishnesh Pujari'),
  # Define Tabs for the UI
  tabsetPanel(type = "tabs", 
              tabPanel("MAP", plotOutput("usmap")), 
              tabPanel("PLOT", plotOutput("view"))
  ),
  
  
  # Define Table of variables
  fluidRow(
    column(3,
           tags$b("List of Clustered Cities"),
           downloadButton('downloadData', 'Download'),
           hr(),
           sliderInput("freq1",
                       "Total Population:",
                       min = 1,  max = 5, value = 1),
           sliderInput("freq2",
                       "Population Density:",
                       min = 1,  max = 5, value = 1)



    ),
    column(3,
           sliderInput("freq3",
                       "Per Capita Income:",
                       min = 1,  max = 5, value = 1),
           sliderInput("freq4",
                       "Household Income:",
                       min = 1,  max = 5, value = 1),
           sliderInput("freq5",
                       "Household Below Poverty:",
                       min = 1,  max = 5, value = 1)


    ),
    column(3,
           sliderInput("freq8",
                       "Education-Bachelors Degree and 25+:",
                       min = 1,  max = 5, value = 1),
           sliderInput("freq6",
                       "Management,Business,Science Occupation:",
                       min = 1,  max = 5, value = 1),
           sliderInput("freq7",
                       "Household with 65+:",
                       min = 1,  max = 5, value = 1)

),
    column(3,
           sliderInput("freq9",
                       "% Owner Occupied Household:",
                       min = 1,  max = 5, value = 1),
           sliderInput("freq10",
                       "Foreign Born:",
                       min = 1,  max = 5, value = 1),
           sliderInput("freq11",
                       "Minority Population:",
                       min = 1,  max = 5, value = 1)
           )
  )
))