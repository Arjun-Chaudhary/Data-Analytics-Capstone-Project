# Load data.table package
require(data.table)

# Load Shiny App
require(shiny)

# Load Maps
require(mapproj)

#Load Custplot
require(cluster)

# Load Maps
require(maps)

# Load for Colors
library(RColorBrewer)

# library(qVarSel)
# library(dplyr)
# require(fastmatch)

# Read dataset "new_variables" from the Data sirectory
mydata <-read.csv("Data/new_variables.csv",header = TRUE)

#Copy data to new data table, so that we do not modify the oroginal data frame
new_cap_data<-as.data.table(copy(mydata))

# Delete the columns without continuous variables
sub_cap_data <- new_cap_data[,c(1,2,3):=NULL]

# Scale columns to reduce effect of outliers in the dataset
sub_cap_data<- as.data.table(scale(sub_cap_data, center = TRUE, scale = TRUE))


# Define Server Function
shinyServer(function(input, output, session) {
 
   # Define a reactive expression to capture data with weighted variables
  data_set<- reactive({
    # Capture variable name
    temp1<-'TOTAL_POPULATION'
    
    # weight of the variable from UI.R
    sca_data1<-input$freq1
    y <- copy(sub_cap_data)
    
    # Modifying the value by scaling the variable with weights
    expr = paste0("y[,",temp1,":=sca_data1*(",temp1,")]")
    eval(parse(text=expr))
    
    temp2<-'POPU_DENSITY'
    sca_data2<-input$freq2
    expr = paste0("y[,",temp2,":=sca_data2*(",temp2,")]")
    eval(parse(text=expr))
    
    temp3<-'INC_PER_CAP'
    sca_data3<-input$freq3
    expr = paste0("y[,",temp3,":=sca_data3*(",temp3,")]")
    eval(parse(text=expr))
    
    temp4<-'INC_HM_VALUE'
    sca_data4<-input$freq4
    expr = paste0("y[,",temp4,":=sca_data4*(",temp4,")]")
    eval(parse(text=expr))
    
    temp5<-'INC_BL_POVERTY'
    sca_data5<-input$freq5
    expr = paste0("y[,",temp5,":=sca_data5*(",temp5,")]")
    eval(parse(text=expr))
    
    temp6<-'WF_OCCUP'
    sca_data6<-input$freq6
    expr = paste0("y[,",temp6,":=sca_data6*(",temp6,")]")
    eval(parse(text=expr))

    temp7<-'HH_OVR_65'
    sca_data7<-input$freq7
    expr = paste0("y[,",temp7,":=sca_data7*(",temp7,")]")
    eval(parse(text=expr))
    
    temp8<-'WF_OVR_25'
    sca_data8<-input$freq8
    expr = paste0("y[,",temp8,":=sca_data8*(",temp8,")]")
    eval(parse(text=expr))
    
    temp9<-'HH_PER_OW_OC'
    sca_data9<-input$freq9
    expr = paste0("y[,",temp9,":=sca_data9*(",temp9,")]")
    eval(parse(text=expr))
    
    temp10<-'DI_FB'
    sca_data10<-input$freq10
    expr = paste0("y[,",temp10,":=sca_data10*(",temp10,")]")
    eval(parse(text=expr))
    
    temp11<-'DI_RACE'
    sca_data11<-input$freq11
    expr = paste0("y[,",temp11,":=sca_data11*(",temp11,")]")
    eval(parse(text=expr))
    
    y
  })
  
# Reactive expression to capture result of K-Means
  clusters <- reactive({
    kmeans(data_set(), centers = 8)
  })
  
  

# PLot the K-Means Plot using clusplot function 
 output$view <- renderPlot({clusplot(data_set(), clusters()$cluster, color =TRUE, shade=TRUE, 
           labels=4, lines=0, main = "K-MEANS PLOT")})

 #Capturing the list of counties by cluster
 new_data<-reactive({

clust<-clusters()$cluster

   new_clust_data <- cbind.data.frame(cluster=clust,region=mydata$REGION, County=mydata$COUNTY)})


 # To plot the highlighted map
 output$usmap <- renderPlot({
   colors = brewer.pal(8,"Set1")
   map("county", col = colors[new_data()$cluster], fill = TRUE, resolution = 0,
       lty = 0, projection = "polyconic")
   map("state", col = "white", fill = FALSE, add = TRUE, lty = 1, lwd = 0.2,
       projection="polyconic")
   title("Clusters of Similar Counties in US")
   legend("bottomright", legend=paste("cluster",sort(unique(new_data()$cluster))), horiz = F, fill = colors, title="List of Clusters")
   
   })
 
 # Configure the Download functionality
 output$downloadData <- downloadHandler(
   filename = function() { 
     paste('cluster', '.csv', sep='') 
   },
   content = function(file) {
     write.csv(new_data(), file, row.names = F)
   }
 )
})